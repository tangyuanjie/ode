#define IDI_MYICON             101
