#ifndef WINFUNCS_H
#define WINFUNCS_H

UINT APIENTRY ColorDialogHook(HWND hdlg, UINT msg, WPARAM, LPARAM);
void GetLightColor();

#endif
