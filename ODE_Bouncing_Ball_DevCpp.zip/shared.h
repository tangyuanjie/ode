#ifndef SHARED_H
#define SHARED_H

#pragma warning( disable : 4244 4305 )  // Disable warning messages

#include <iostream>
using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>

#ifdef __cplusplus
}
#endif

#endif //SHARED_H
